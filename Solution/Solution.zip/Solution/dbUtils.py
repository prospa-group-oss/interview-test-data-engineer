import sqlite3
from sqlite3 import Error

def createDB(dbFile):
    #create a database connection to a new SQLite database 
    try:
        conn = sqlite3.connect(dbFile)
        print("Successfully created database: " + dbFile)
    except Error as e:
        print(e)
    finally:
        conn.close()

def connectDB(dbFile):
    try:
        conn = sqlite3.connect(dbFile)
        print("Successfully connected to database: " + dbFile)
        return conn
    except Error as e:
        print(e)
    return None

def createTable(conn, tableName, sql):
    try:
        c = conn.cursor()
        c.execute(sql)
        print("Successfully created table: " + tableName)
    except Error as e:
        print(e)

def closeDB(conn):    
    conn.close()
    print("Successfully closed DB connection")