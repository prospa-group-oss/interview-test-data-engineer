import os
import dbUtils
import cleanup
import json
import logging
import csv

def setupDB(dbName, dbFilePath, ddlFileName, ddlFilePath):
    dbFile = dbFilePath + "\\" + dbName + ".db"

    #Create a new database to store the raw data
    dbUtils.createDB(dbFile)

def main():
    # define the name of the directories to be created
    path = os.getcwd()
    dbFilePath = path + "\\DBFiles"
    ddlFilePath = path + "\\DDLFiles"

    try:
        #Check if the directory exists and delete if it does
        if os.path.isdir(dbFilePath):
            cleanup.cleanupFolder(dbFilePath)
        #Create directory to house database files
        os.mkdir(dbFilePath)
    except OSError:
        print ("Creation of the directory %s failed" % dbFilePath)
    else:
        print ("Successfully created the directory %s " % dbFilePath)

    #Create tables for the raw database to store source data
    setupDB("raw", dbFilePath, "rawDDL.json", ddlFilePath)
    #Create tables for the dwh database to store the star schema
    setupDB("dwh", dbFilePath, "starDDL.json", ddlFilePath)

if __name__ == '__main__':
    main()