import os
import dbUtils
import pandas as pd
import sqlite3 

def main():
    try:
        #Connect to star schema
        dbFile = os.getcwd() + "\\DBFiles\\star.db"

        conn = dbUtils.connectDB(dbFile)

        if conn is not None:

            with conn:
                print("1. What are the top 5 nations in terms of revenue?")
                sql = "\
                    SELECT \
                        c.c_nation, \
                        SUM(lo.lo_revenue) AS totalrevenue \
                    FROM \
                        lineorder lo \
                        INNER JOIN customer c ON c.c_custkey = lo.lo_custkey \
                    WHERE\
                        lo.lo_returnflag <> 'R'\
                    GROUP BY c.c_nation \
                    ORDER BY 2 \
                    DESC LIMIT 5;"

                df = pd.read_sql(sql, con=conn, index_col=None)        
                df = pd.DataFrame(df,columns=['c_nation'])
                print(df)
                print("  ")

                print("2. From the top 5 nations, what is the most common shipping mode?")
                sql = "\
                    WITH nation AS (\
                        SELECT \
                            c.c_nation, \
                            SUM(lo.lo_revenue) AS totalrevenue \
                        FROM \
                            lineorder lo \
                            INNER JOIN customer c ON c.c_custkey = lo.lo_custkey \
                        WHERE\
                            lo.lo_returnflag <> 'R'\
                        GROUP BY c.c_nation \
                        ORDER BY 2 \
                        DESC LIMIT 5\
                    )\
                    SELECT \
                        lo.lo_shipmode,\
                        COUNT(1) AS shipmodecount\
                    FROM\
                        nation n\
                        INNER JOIN customer c ON c.c_nation = n.c_nation\
                        INNER JOIN lineorder lo ON c.c_custkey = lo.lo_custkey\
                    GROUP BY lo.lo_shipmode\
                    ORDER BY 2 desc\
                    LIMIT 1;"
                df = pd.read_sql(sql, con=conn, index_col=None)        
                df = pd.DataFrame(df,columns=['lo_shipmode'])
                print(df)
                print("  ")

                print("3. What are the top selling months?")
                sql = "\
                    SELECT\
                        STRFTIME('%m', lo.lo_orderdate) AS Month,\
                        SUM(lo.lo_revenue) AS totalrevenue\
                    FROM\
                        lineorder lo\
                    WHERE\
                        lo.lo_returnflag <> 'R'\
                    GROUP BY STRFTIME('%m', lo.lo_orderdate)\
                    ORDER BY 2 DESC\
                    LIMIT 3;"
                df = pd.read_sql(sql, con=conn, index_col=None)        
                df = pd.DataFrame(df,columns=['Month'])
                print(df)
                print("  ")

                print("4.1 Who are the top customer in terms of revenue and/or quantity? Revenue:")
                sql = "\
                    SELECT \
                        c.c_custkey,\
                        c.c_name,\
                        SUM(lo.lo_revenue) AS totalrevenue\
                    FROM\
                        lineorder lo\
                        INNER JOIN customer c ON c.c_custkey = lo.lo_custkey\
                    WHERE\
                        lo.lo_returnflag <> 'R'\
                    GROUP BY\
                        c.c_custkey,\
                        c.c_name\
                    ORDER BY 2 DESC\
                    LIMIT 5;"
                df = pd.read_sql(sql, con=conn, index_col=None)        
                df = pd.DataFrame(df,columns=['c_name'])
                print(df)
                print("  ")

                print("4.2 Who are the top customer in terms of revenue and/or quantity? Quantity: ")
                sql = "\
                    SELECT \
                        c.c_custkey,\
                        c.c_name,\
                        SUM(lo.lo_quantity) AS totalquantity\
                    FROM\
                        lineorder lo\
                        INNER JOIN customer c ON c.c_custkey = lo.lo_custkey\
                    WHERE\
                        lo.lo_returnflag <> 'R'\
                    GROUP BY\
                        c.c_custkey,\
                        c.c_name\
                    ORDER BY 2 DESC\
                    LIMIT 5;"
                df = pd.read_sql(sql, con=conn, index_col=None)        
                df = pd.DataFrame(df,columns=['c_name'])
                print(df)
                print("  ")

                print("5. Compare the sales revenue of one current period against previous period?")
                sql = "\
                    WITH yearRevenue AS (\
                        SELECT\
                            STRFTIME('%Y', lo_orderdate) AS yr,\
                            SUM(lo_revenue) AS revenue,\
                            LAG(SUM(lo_revenue)) OVER(ORDER BY STRFTIME('%Y', lo_orderdate) ASC) AS previousyearrevenue\
                        FROM\
                            lineorder lo\
                        WHERE\
                            lo.lo_returnflag <> 'R'\
                        GROUP BY STRFTIME('%Y', lo_orderdate)	\
                    )\
                    SELECT\
                        y.yr,\
                        y.revenue,\
                        y.previousyearrevenue,\
                        ROUND((y.revenue - y.previousyearrevenue) / y.previousyearrevenue * 100, 2) AS yoypercent\
                    FROM \
                        yearRevenue y;"
                df = pd.read_sql(sql, con=conn, index_col=None)   
                print(df)
                print("  ")

    except Exception as e:
        print(e)

if __name__ == '__main__':
    main()
