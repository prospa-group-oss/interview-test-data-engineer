import os
import shutil

def cleanupFolder(folderPath):

    try:
        #Delete the folder and all contents
        shutil.rmtree(folderPath) 
    except OSError:
        print ("Deletion of the directory %s failed" % folderPath)
    else:
        print ("Successfully deleted the directory %s" % folderPath)

def main():
    folderPath = os.getcwd() + "\\DBFiles"
    cleanupFolder(folderPath)

if __name__ == '__main__':
    main()