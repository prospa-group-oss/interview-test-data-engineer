import os
import dbUtils
import pandas as pd
import sqlite3
import json
import logging

def loadData(loadType):
    #Setup parameters
    path = os.getcwd()
    rawDBFile = path + "\\DBFiles\\raw.db"
    starDBFile = path + "\\DBFiles\\star.db"
    rawDDLFile = path + "\\DDLFiles\\rawDDL.json"
    starETLFile = path + "\\ETLFiles\\starETL.json"

    try:
        if loadType == 'RAW':
            #get a connection to the database
            rawConn = dbUtils.connectDB(rawDBFile)
            if rawConn is not None:
                #Open the JsonFile and iteratively fetch source file and load the relevant SQL table
                with open(rawDDLFile) as jsonFile:
                    data = json.load(jsonFile)

                    for idx in data.keys():
                        table = data[idx]["tableName"]
                        columns = data[idx]["columns"]              
                        filePath = path + "\\DataFiles\\" + table + ".tbl"
                        #Open dataframe and specify tabular format
                        df = pd.read_table(filePath, sep='|', header=None, index_col=False, names = columns) 
                        #Load data to SQL table
                        df.to_sql(name=table, con=rawConn, if_exists='replace', index=False)
                        print("Loading table " + table)

        elif loadType == 'DWH':
            
            #get a connection to the database
            rawConn = dbUtils.connectDB(rawDBFile)
            dwhConn = dbUtils.connectDB(starDBFile)

            if dwhConn is not None and rawConn is not None:
                #Open the JsonFile and iteratively fetch source file and load the relevant SQL table
                with open(starETLFile) as jsonFile:
                    data = json.load(jsonFile)
                    
                    for idx in data.keys():
                        table = data[idx]["tableName"]
                        sql = data[idx]["sql"]
                        #Open dataframe for sql
                        df = pd.read_sql(sql, con=rawConn, index_col=None)
                        #Load data to SQL table
                        df.to_sql(name=table, con=dwhConn, if_exists='replace', index=False)
                        dwhConn.commit()
                        print("Loading table " + table)

                    dbUtils.closeDB(rawConn)
                    dbUtils.closeDB(dwhConn)
        else:
            print("Invalid load type")

    except Exception as e:
        print(e)

def main():
    loadData("RAW")
    loadData("DWH")

if __name__ == '__main__':
    main()